M3 Template v0.8 for the 010 Editor
by NiNtoxicated

Parses the Starcraft 2 Model file format (.M3) into more easily managed structures within the hex editor 010 Editor.

Install instructions:
1. Install 010 Editor (30 day trial at the moment unfortunately, older versions were free) from:
http://www.sweetscape.com/010editor/

2. Extract the template (.bt) into '...\My Documents\SweetScape\010 Templates\' (default template directory for 010 Editor) or a custom path.

3. Open the Template through the editor toolbar, select the template from the drop down list with an M3 file open and hit run template.


